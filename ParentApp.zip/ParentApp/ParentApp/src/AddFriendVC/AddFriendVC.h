//
//  AddFriendVC.h
//  ParentApp
//
//  Created by Lius on 14-5-9.
//  Copyright (c) 2014年 edu.sysu.davidlau.ios. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AddFriendVC : UIViewController
@property (weak, nonatomic) IBOutlet UIImageView *QRImageView;
@property (weak, nonatomic) IBOutlet UILabel *labelParentName;
@property (weak, nonatomic) IBOutlet UILabel *labelHint;

@end
