//
//  MainViewController.m
//  RegLogVeriUser
//
//  Created by Lius on 14-4-27.
//  Copyright (c) 2014年 edu.sysu.davidlau.ios. All rights reserved.
//

#import "WelcomeVC.h"

@interface WelcomeVC ()

@end

@implementation WelcomeVC

- (void)viewDidLoad
{
    [super viewDidLoad];
	// Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
