//
//  MainViewController.h
//  RegLogVeriUser
//
//  Created by Lius on 14-4-27.
//  Copyright (c) 2014年 edu.sysu.davidlau.ios. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface WelcomeVC : UIViewController

@end
