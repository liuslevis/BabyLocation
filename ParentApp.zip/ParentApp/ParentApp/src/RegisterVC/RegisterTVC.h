//
//  RegisterTVC.h
//  RegLogVeriUser
//
//  Created by Lius on 14-4-28.
//  Copyright (c) 2014年 edu.sysu.davidlau.ios. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppConstants.h"
#import "DavidlauUtils.h"
@interface RegisterTVC : UITableViewController

@end
