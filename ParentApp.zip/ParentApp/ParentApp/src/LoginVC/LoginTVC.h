//
//  LoginTVC.h
//  RegLogVeriUser
//
//  Created by Lius on 14-4-27.
//  Copyright (c) 2014年 edu.sysu.davidlau.ios. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "DavidlauUtils.h"
@interface LoginTVC : UITableViewController


@end
