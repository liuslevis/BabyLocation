//
//  LocationAPI.m
//  ParentApp
//
//  Created by Lius on 14-5-11.
//  Copyright (c) 2014年 edu.sysu.davidlau.ios. All rights reserved.
//

#import "LocationAPI.h"

@implementation LocationAPI

@end
