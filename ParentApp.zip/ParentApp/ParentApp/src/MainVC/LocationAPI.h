//
//  LocationAPI.h
//  ParentApp
//
//  Created by Lius on 14-5-11.
//  Copyright (c) 2014年 edu.sysu.davidlau.ios. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LocationAPI : NSObject

@end
