//
//  MainViewController.h
//  ParentApp
//
//  Created by Lius on 14-4-28.
//  Copyright (c) 2014年 edu.sysu.davidlau.ios. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MainViewController : UIViewController

@end
